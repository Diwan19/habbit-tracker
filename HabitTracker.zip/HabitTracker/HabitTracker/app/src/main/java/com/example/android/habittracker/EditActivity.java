package com.example.android.habittracker;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v4.app.NavUtils;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;
import com.example.android.habittracker.data.MedDbHelper;
import com.example.android.habittracker.data.MedContract.MedEntry;

import static com.example.android.habittracker.R.id.frequency;


public class EditActivity extends AppCompatActivity {
    private EditText mMedEditText;

    private EditText mFrequencyEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.editor_activity);


        mMedEditText = (EditText) findViewById(R.id.habit);
        mFrequencyEditText = (EditText) findViewById(frequency);
    }

    private void insertHabit(){
        String medString = mMedEditText.getText().toString().trim();
        String frequencyString = mFrequencyEditText.getText().toString().trim();
        int frequency = Integer.parseInt(frequencyString);

        MedDbHelper mDbHelper = new MedDbHelper(this);

        SQLiteDatabase db = mDbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(MedEntry.COLUMN_MEDI_NAME, medString);
        values.put(MedEntry.COLUMN_MEDI_FREQUENCY, frequency);

        long newRowId = db.insert(MedEntry.TABLE_NAME, null, values);

        if (newRowId == -1) {
            // If the row ID is -1, then there was an error with insertion.
            Toast.makeText(this, "Error with saving habit", Toast.LENGTH_SHORT).show();
        } else {
            // Otherwise, the insertion was successful and we can display a toast with the row ID.
            Toast.makeText(this, "habit saved with row id: " + newRowId, Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menuedit, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
                        case R.id.action_save:
                insertHabit();
                finish();
                return true;
            case android.R.id.home:
                // Navigate back to parent activity (CatalogActivity)
                NavUtils.navigateUpFromSameTask(this);
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
