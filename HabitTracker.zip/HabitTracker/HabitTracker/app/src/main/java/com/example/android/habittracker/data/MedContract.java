package com.example.android.habittracker.data;

import android.provider.BaseColumns;


public final class MedContract {
    private MedContract(){  };

    public static final class MedEntry implements BaseColumns {

        public final static String TABLE_NAME="habit";
        public final static String _ID=BaseColumns._ID;
        public final static String COLUMN_MEDI_NAME ="name";
        public final static String COLUMN_MEDI_FREQUENCY ="frequency";
    }
}
