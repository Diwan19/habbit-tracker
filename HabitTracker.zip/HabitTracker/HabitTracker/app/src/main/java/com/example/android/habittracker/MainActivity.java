package com.example.android.habittracker;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

import com.example.android.habittracker.data.MedContract.MedEntry;
import com.example.android.habittracker.data.MedDbHelper;

public class MainActivity extends AppCompatActivity {
    private MedDbHelper mDbHelper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fabid);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, EditActivity.class);
                startActivity(intent);
            }
        });

        mDbHelper = new MedDbHelper(this);

        displayDatabaseInfo();
    }
    @Override
    protected void onStart() {
        super.onStart();
        displayDatabaseInfo();
    }

    private Cursor read(){
        SQLiteDatabase db = mDbHelper.getReadableDatabase();
        return db.query(
                MedEntry.TABLE_NAME, null,
                null,
                null,
                null,
                null,
                null);
    }

    private void displayDatabaseInfo() {
        String[] projection = {
                MedEntry._ID,
                MedEntry.COLUMN_MEDI_NAME,
                MedEntry.COLUMN_MEDI_FREQUENCY,
        };
        Cursor cursor = read();
        TextView displayView = (TextView) findViewById(R.id.text_view_habit);

        try {
            displayView.setText("The habit table contains " + cursor.getCount() + " medicines.\n\n");
            displayView.append(MedEntry._ID + " - " +
                    MedEntry.COLUMN_MEDI_NAME + " - " +
                    MedEntry.COLUMN_MEDI_FREQUENCY);

            // Figure out the index of each column
            int idColumnIndex = cursor.getColumnIndex(MedEntry._ID);
            int medColumnIndex = cursor.getColumnIndex(MedEntry.COLUMN_MEDI_NAME);
            int frequencyColumnIndex = cursor.getColumnIndex(MedEntry.COLUMN_MEDI_FREQUENCY);

            while (cursor.moveToNext()) {
                int currentID = cursor.getInt(idColumnIndex);
                String currentMed = cursor.getString(medColumnIndex);
                int currentFrequency = cursor.getInt(frequencyColumnIndex);

                displayView.append(("\n" + currentID+"." +
                        currentMed + "  " +
                        currentFrequency ));
            }
        } finally {
            cursor.close();
        }
    }
    private void insertHabit(){

        SQLiteDatabase db = mDbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(MedEntry.COLUMN_MEDI_NAME, "crocin");
        values.put(MedEntry.COLUMN_MEDI_FREQUENCY, "2");
        long newRowId = db.insert(MedEntry.TABLE_NAME, null, values);
    }
}
